<?php
require_once __DIR__ . '/includes/image-utils.php';

// If an id is provided, render that portfolio item dynamically.
$contentDataFile = __DIR__ . '/data/content-data.json';
$portfolioItem = null;
if (isset($_GET['id']) && is_numeric($_GET['id']) && file_exists($contentDataFile)) {
  $json = file_get_contents($contentDataFile);
  $loaded = json_decode($json, true);
  if ($loaded && !empty($loaded['portfolio'])) {
    foreach ($loaded['portfolio'] as $p) {
      if ((int)$p['id'] === (int)$_GET['id']) { $portfolioItem = $p; break; }
    }
  }
}
// If exporting static, allow $STATIC_EXPORT to be set externally and use $_GET['id'] if available.
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Portfolio Details - EasyFolio Bootstrap Template</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Noto+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Questrial:wght@400&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- Project: Customized EasyFolio template for Shikhar Joshi -->
</head>

<body class="portfolio-details-page">

  <header id="header" class="header d-flex align-items-center sticky-top">
    <div class="header-container container-fluid container-xl position-relative d-flex align-items-center justify-content-between">

      <a href="index.php" class="logo d-flex align-items-center me-auto me-xl-0">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.webp" alt=""> -->
        <h1 class="sitename">Shikhar Joshi</h1>
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="#hero">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#resume">Resume</a></li>
          <li><a href="#portfolio">Portfolio</a></li>
          <li><a href="#services">Services</a></li>
          <li class="dropdown"><a href="#"><span>Dropdown</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
              <li><a href="#">Dropdown 1</a></li>
              <li class="dropdown"><a href="#"><span>Deep Dropdown</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
                <ul>
                  <li><a href="#">Deep Dropdown 1</a></li>
                  <li><a href="#">Deep Dropdown 2</a></li>
                  <li><a href="#">Deep Dropdown 3</a></li>
                  <li><a href="#">Deep Dropdown 4</a></li>
                  <li><a href="#">Deep Dropdown 5</a></li>
                </ul>
              </li>
              <li><a href="#">Dropdown 2</a></li>
              <li><a href="#">Dropdown 3</a></li>
              <li><a href="#">Dropdown 4</a></li>
            </ul>
          </li>
          <li><a href="#contact">Contact</a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

      <div class="header-social-links">
        <a href="https://www.linkedin.com/in/joshishikhar" target="_blank" class="linkedin"><i class="bi bi-linkedin"></i></a>
        <a href="mailto:joshishikhar05@gmail.com" class="envelope"><i class="bi bi-envelope"></i></a>
        <a href="admin-images.php" class="admin-panel" title="Manage Images"><i class="bi bi-image"></i></a>
      </div>

    </div>
  </header>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title">
      <div class="breadcrumbs">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#"><i class="bi bi-house"></i> Home</a></li>
            <li class="breadcrumb-item"><a href="#">Category</a></li>
            <li class="breadcrumb-item active current">Portfolio Details</li>
          </ol>
        </nav>
      </div>

      <div class="title-wrapper">
        <h1><?php echo $portfolioItem ? htmlspecialchars($portfolioItem['title']) : 'Portfolio Details'; ?></h1>
        <p><?php echo $portfolioItem ? htmlspecialchars($portfolioItem['description']) : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.'; ?></p>
      </div>
    </div><!-- End Page Title -->

    <!-- Portfolio Details Section -->
    <section id="portfolio-details" class="portfolio-details section">

      <div class="container" data-aos="fade-up">

        <div class="row gy-4 g-lg-5">
          <div class="col-lg-6">
            <?php if ($portfolioItem): ?>
              <img src="<?php echo htmlspecialchars(getImagePath('portfolio', $portfolioItem['image'])); ?>" class="img-fluid mb-4" alt="<?php echo htmlspecialchars($portfolioItem['title']); ?>">
            <?php else: ?>
              <img src="assets/img/portfolio/portfolio-1.webp" class="img-fluid mb-4" alt="">
              <img src="assets/img/portfolio/portfolio-10.webp" class="img-fluid mb-4" alt="">
              <img src="assets/img/portfolio/portfolio-7.webp" class="img-fluid mb-4" alt="">
              <img src="assets/img/portfolio/portfolio-4.webp" class="img-fluid mb-4" alt="">
              <img src="assets/img/portfolio/portfolio-5.webp" class="img-fluid mb-4" alt="">
              <img src="assets/img/portfolio/portfolio-11.webp" class="img-fluid mb-4" alt="">
              <img src="assets/img/portfolio/portfolio-8.webp" class="img-fluid mb-4" alt="">
            <?php endif; ?>
          </div>

          <div class="col-lg-6">

            <div class="position-sticky" style="top: 40px">
                <div class="portfolio-description">
                <h2><?php echo $portfolioItem ? htmlspecialchars($portfolioItem['title']) : 'This is an example of portfolio details'; ?></h2>
                <p>
                  <?php echo $portfolioItem ? nl2br(htmlspecialchars($portfolioItem['description'])) : 'Autem ipsum nam porro corporis rerum. Quis eos dolorem eos itaque inventore commodi labore quia quia. Exercitationem repudiandae officiis neque suscipit non officia eaque itaque enim. Voluptatem officia accusantium nesciunt est omnis tempora consectetur dignissimos. Sequi nulla at esse enim cum deserunt eius.'; ?>
                </p>
                <?php if (!$portfolioItem): ?>
                <p>
                  Amet consequatur qui dolore veniam voluptatem voluptatem sit. Non aspernatur atque natus ut cum nam et. Praesentium error dolores rerum minus sequi quia veritatis eum. Eos et doloribus doloremque nesciunt molestiae laboriosam.
                </p>
                <?php endif; ?>

                <div class="testimonial-item">
                  <p>
                    <i class="bi bi-quote quote-icon-left"></i>
                    <span>Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum eram malis quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa.</span>
                    <i class="bi bi-quote quote-icon-right"></i>
                  </p>
                  <div>
                    <img src="assets/img/person/person-f-5.webp" class="testimonial-img" alt="">
                    <h3>Sara Wilsson</h3>
                    <h4>Designer</h4>
                  </div>
                </div>

                <p>
                  Impedit ipsum quae et aliquid doloribus et voluptatem quasi. Perspiciatis occaecati earum et magnam animi. Quibusdam non qui ea vitae suscipit vitae sunt. Repudiandae incidunt cumque minus deserunt assumenda tempore. Delectus voluptas necessitatibus est.
                </p>

                <p>
                  Sunt voluptatum sapiente facilis quo odio aut ipsum repellat debitis. Molestiae et autem libero. Explicabo et quod necessitatibus similique quis dolor eum. Numquam eaque praesentium rem et qui nesciunt.
                </p>

              </div>

              <div class="portfolio-info mt-5">
                <h3>Project information</h3>
                <ul>
                  <li><strong>Category</strong> Web design</li>
                  <li><strong>Client</strong> ASU Company</li>
                  <li><strong>Project date</strong> 01 March, 2020</li>
                  <li><strong>Project URL</strong> <a href="#">www.example.com</a></li>
                  <li><a href="#" class="btn-visit align-self-start">Visit Website</a></li>
                </ul>
              </div>
            </div>

          </div>
        </div>

      </div>

    </section><!-- /Portfolio Details Section -->

  </main>

  <footer id="footer" class="footer">

    <div class="container">
      <div class="copyright text-center ">
        <p>© <span>Copyright</span> <strong class="px-1 sitename">EasyFolio</strong> <span>All Rights Reserved</span></p>
      </div>
      <div class="social-links d-flex justify-content-center">
        <a href=""><i class="bi bi-twitter-x"></i></a>
        <a href=""><i class="bi bi-facebook"></i></a>
        <a href=""><i class="bi bi-instagram"></i></a>
        <a href=""><i class="bi bi-linkedin"></i></a>
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you've purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
        &nbsp;|&nbsp; Customized and Managed by <a href="index.html">Shikhar Joshi</a>
      </div>
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>